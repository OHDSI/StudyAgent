const form = document.getElementById("intent-form");
const studyIntentInput = document.getElementById("study-intent");
const goButton = document.getElementById("go-button");
const clearIntentButton = document.getElementById("clear-intent-button");
const resetResultsButton = document.getElementById("reset-results-button");
const statusEl = document.getElementById("status");
const resultsPanel = document.getElementById("results-panel");
const errorPanel = document.getElementById("error-panel");
const recommendationList = document.getElementById("recommendation-list");
const resultSummary = document.getElementById("result-summary");
const jsonOutput = document.getElementById("json-output");
const errorOutput = document.getElementById("error-output");

function setLoading(isLoading, message = "") {
  goButton.disabled = isLoading;
  clearIntentButton.disabled = isLoading;
  if (resetResultsButton) {
    resetResultsButton.disabled = isLoading;
  }
  statusEl.textContent = message;
}

function escapeHtml(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function clearResults() {
  recommendationList.innerHTML = "";
  resultSummary.textContent = "";
  jsonOutput.textContent = "";
  errorOutput.textContent = "";
  resultsPanel.classList.add("hidden");
  errorPanel.classList.add("hidden");
  statusEl.textContent = "";
}

function renderRecommendations(payload) {
  const recommendations = payload?.recommendations?.phenotype_recommendations || [];
  const shortlist = payload?.planning?.shortlist_ids || [];

  recommendationList.innerHTML = "";
  if (!recommendations.length) {
    recommendationList.innerHTML = '<li class="empty-state">No recommendations returned.</li>';
  } else {
    recommendations.forEach((item, index) => {
      const li = document.createElement("li");
      li.className = "recommendation-item";
      const title = escapeHtml(item.phenotype_name || item.phenotype_id || `Recommendation ${index + 1}`);
      const phenotypeId = escapeHtml(item.phenotype_id || "");
      const justification = escapeHtml(item.justification || "No justification returned.");
      const confidence = escapeHtml(item.confidence || "");
      const phenotypeHref = item.phenotype_id ? `./phenotype.html?id=${encodeURIComponent(item.phenotype_id)}` : "#";

      li.innerHTML = `
        <div class="recommendation-topline">
          <span class="rank">#${index + 1}</span>
          <div>
            <h3>${title}</h3>
            <p class="meta">${phenotypeId}${confidence ? ` · confidence: ${confidence}` : ""}</p>
          </div>
        </div>
        <p class="justification">${justification}</p>
        ${item.phenotype_id ? `<p class="card-link-row"><a class="card-link" href="${phenotypeHref}" target="_blank" rel="noopener noreferrer">Open phenotype definition</a></p>` : ""}
      `;
      recommendationList.appendChild(li);
    });
  }

  resultSummary.textContent = `Returned ${recommendations.length} recommendation(s). Shortlist ids: ${shortlist.join(", ") || "none"}.`;
  jsonOutput.textContent = JSON.stringify(payload, null, 2);
  resultsPanel.classList.remove("hidden");
  errorPanel.classList.add("hidden");
}

function renderError(payload) {
  errorOutput.textContent = JSON.stringify(payload, null, 2);
  errorPanel.classList.remove("hidden");
  resultsPanel.classList.add("hidden");
}

clearIntentButton.addEventListener("click", () => {
  studyIntentInput.value = "";
  studyIntentInput.focus();
  statusEl.textContent = "";
});

if (resetResultsButton) {
  resetResultsButton.addEventListener("click", () => {
    clearResults();
  });
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const studyIntent = studyIntentInput.value.trim();
  if (!studyIntent) {
    renderError({ error: "invalid_request", detail: "Study intent is required." });
    return;
  }

  setLoading(true, "Running phenotype recommendation...");
  try {
    const response = await fetch("/api/recommend", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ study_intent: studyIntent }),
    });
    const payload = await response.json();
    if (!response.ok) {
      renderError(payload);
    } else {
      renderRecommendations(payload);
    }
  } catch (error) {
    renderError({ error: "request_failed", detail: String(error) });
  } finally {
    setLoading(false, "");
  }
});
