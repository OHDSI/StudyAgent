from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, unquote, urlsplit
from urllib.request import Request, urlopen


HOST = "127.0.0.1"
PORT = 8010
ACP_RECOMMENDATION_URL = "http://127.0.0.1:8765/flows/phenotype_recommendation"
ACP_DEFINITION_URL = "http://127.0.0.1:8765/flows/phenotype_definition"
APP_DIR = Path(__file__).resolve().parent


def _json_response(handler: BaseHTTPRequestHandler, status: int, payload: object) -> None:
    body = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def _post_json(url: str, payload: dict) -> dict:
    request = Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=120) as response:
        body = response.read().decode("utf-8")
        return json.loads(body)


class AppHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path in ("/", "/index.html"):
            self._serve_file("index.html", "text/html; charset=utf-8")
            return
        if parsed.path == "/phenotype.html":
            self._serve_file("phenotype.html", "text/html; charset=utf-8")
            return
        if parsed.path == "/app.js":
            self._serve_file("app.js", "application/javascript; charset=utf-8")
            return
        if parsed.path == "/phenotype.js":
            self._serve_file("phenotype.js", "application/javascript; charset=utf-8")
            return
        if parsed.path == "/styles.css":
            self._serve_file("styles.css", "text/css; charset=utf-8")
            return
        if parsed.path.startswith("/api/phenotype/"):
            phenotype_id = unquote(parsed.path.removeprefix("/api/phenotype/"))
            params = parse_qs(parsed.query)
            view = (params.get("view") or ["assembled"])[0]
            self._serve_phenotype_payload(phenotype_id=phenotype_id, view=view)
            return
        self.send_error(404, "Not found")

    def do_POST(self) -> None:
        if self.path != "/api/recommend":
            self.send_error(404, "Not found")
            return
        length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(length)
        try:
            payload = json.loads(raw_body.decode("utf-8"))
        except json.JSONDecodeError:
            _json_response(self, 400, {"error": "invalid_request", "detail": "Request body must be valid JSON."})
            return

        study_intent = str(payload.get("study_intent") or "").strip()
        if not study_intent:
            _json_response(self, 400, {"error": "invalid_request", "detail": "study_intent is required."})
            return

        acp_payload = {
            "study_intent": study_intent,
            "top_k": 20,
            "max_results": 3,
            "candidate_limit": 10,
        }

        try:
            result = _post_json(ACP_RECOMMENDATION_URL, acp_payload)
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            _json_response(
                self,
                502,
                {
                    "error": "acp_http_error",
                    "detail": f"ACP returned HTTP {exc.code}.",
                    "acp_response_text": detail,
                },
            )
            return
        except URLError as exc:
            _json_response(
                self,
                502,
                {"error": "acp_unreachable", "detail": f"Could not reach ACP at {ACP_RECOMMENDATION_URL}: {exc.reason}"},
            )
            return
        except TimeoutError:
            _json_response(self, 504, {"error": "acp_timeout", "detail": "ACP request timed out."})
            return
        except json.JSONDecodeError:
            _json_response(self, 502, {"error": "invalid_acp_response", "detail": "ACP returned non-JSON output."})
            return

        _json_response(self, 200, result)

    def log_message(self, format: str, *args) -> None:
        return

    def _serve_file(self, name: str, content_type: str) -> None:
        path = APP_DIR / name
        if not path.exists():
            self.send_error(404, "Not found")
            return
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_phenotype_payload(self, phenotype_id: str, view: str) -> None:
        phenotype_id = str(phenotype_id or "").strip()
        if not phenotype_id:
            _json_response(self, 400, {"error": "invalid_request", "detail": "phenotype_id is required."})
            return
        try:
            result = _post_json(ACP_DEFINITION_URL, {"phenotype_id": phenotype_id})
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            _json_response(
                self,
                502,
                {
                    "error": "acp_http_error",
                    "detail": f"ACP returned HTTP {exc.code}.",
                    "acp_response_text": detail,
                },
            )
            return
        except URLError as exc:
            _json_response(
                self,
                502,
                {"error": "acp_unreachable", "detail": f"Could not reach ACP at {ACP_DEFINITION_URL}: {exc.reason}"},
            )
            return
        except TimeoutError:
            _json_response(self, 504, {"error": "acp_timeout", "detail": "ACP request timed out."})
            return
        except json.JSONDecodeError:
            _json_response(self, 502, {"error": "invalid_acp_response", "detail": "ACP returned non-JSON output."})
            return

        if result.get("status") == "error":
            _json_response(self, 502, result)
            return

        document = result.get("document") or {}
        if view == "assembled":
            payload = document
        elif view == "source":
            payload = document.get("definition") or {}
        else:
            _json_response(self, 400, {"error": "invalid_request", "detail": "view must be assembled or source."})
            return
        _json_response(self, 200, payload)


if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), AppHandler)
    print(f"Serving phenotype recommendation review app on http://{HOST}:{PORT}")
    server.serve_forever()
